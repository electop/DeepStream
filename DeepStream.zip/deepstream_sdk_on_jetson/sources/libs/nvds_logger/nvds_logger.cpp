/*
 * Copyright (c) 2018 NVIDIA Corporation.  All rights reserved.
 *
 * NVIDIA Corporation and its licensors retain all intellectual property
 * and proprietary rights in and to this software, related documentation
 * and any modifications thereto.  Any use, reproduction, disclosure or
 * distribution of this software and related documentation without an express
 * license agreement from NVIDIA Corporation is strictly prohibited.
 *
 */
#include <stdio.h>
#include <syslog.h>
#include <stdarg.h>
#include <string.h>
#include "nvds_logger.h"

extern "C" {

void nvds_log_open()
{
  openlog(DSLOG_SYSLOG_IDENT, LOG_PID , LOG_LOCAL1);
}

void nvds_log_close()
{
  closelog();
}

void nvds_log(const char *category,  int priority, const char *data, ...)
{
  char logmsg[2048];
  char *logptr;

  /* this logic is necessary to prepend category in front of the formatted string */
  snprintf(logmsg, sizeof(logmsg), "%s: ", category);
  char catsize = strlen(logmsg);
  logptr = (char *)(logmsg + catsize);
  va_list args;
  va_start(args, data);
  vsnprintf(logptr, (sizeof(logmsg) - catsize), data, args);

  syslog(priority|LOG_LOCAL1, "%s\n", logmsg);
  va_end(args);
}


}

