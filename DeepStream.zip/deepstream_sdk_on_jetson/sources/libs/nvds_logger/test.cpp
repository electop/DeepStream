/*################################################################################
# Copyright (c) 2018, NVIDIA CORPORATION. All rights reserved.
#
# NVIDIA Corporation and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA Corporation is strictly prohibited.
#
################################################################################
# sample test application to perform logging using nvds_logger api's
*/

#include <sys/timeb.h>
#include <stdio.h>
#include "nvds_logger.h"


main()
{

  char data[30];
  int i = 15;

  nvds_log_open();

  /* Using pre-packaged payload based on published JSON schema */
  nvds_log(DSLOG_CAT_SG , LOG_INFO, "{\"@timestamp\":\"2017-09- 02T10:00:00:000Z\", \"location\": \"endeavor\", \"class\": \"general\", \"event\": \"in\", \"Vehicle\": {\"make\": \"Toyota\", \"model\": \"Camry\", \"color\": \"Green\", \"licenseState\": \"CA\", \"license\": \"0000000\"}}");


  /* close log when all done */
  nvds_log_close();
}
