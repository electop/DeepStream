/* Copyright (c) 2017-2018, NVIDIA CORPORATION.  All rights reserved.
 *
 * NVIDIA CORPORATION and its licensors retain all intellectual property
 * and proprietary rights in and to this software, related documentation
 * and any modifications thereto.  Any use, reproduction, disclosure or
 * distribution of this software and related documentation without an express
 * license agreement from NVIDIA CORPORATION is strictly prohibited.
 */

/**
 * @file
 * <b>NVIDIA DeepStream: Buffer Structure</b>
 *
 * @b Description: This file specifies the NVIDIA DeepStream GStreamer batched
 * buffer structure.
 */

/**
 * @defgroup gstreamer_buffer Buffer Structures
 * Defines buffer structures.
 * @ingroup gstreamer_utilities_group
 * @{
 *
 * Clients use the @ref NvBufSurface structure to access the
 * buffers that DeepStream GStreamer components allocate.
 * Additionally, they can use it to access the related
 * buffer format information.
 *
 * To get NvBufSurface structure from a DeepStream GStreamer buffer,
 * use the following snippet:
 *
 * @code
 *  GstMapInfo info = GST_MAP_INFO_INIT;
 *  NvBufSurface *nvbuf = NULL;
 *
 *  if (!gst_buffer_map (gstbuf, &info, GST_MAP_READ)) {
 *    goto map_error;
 *  }
 *
 *  nvbuf = (*(NvBufSurface **) info.data);
 *
 *  gst_buffer_unmap (gstbuf, &info);
 *
 * map_error:
 *  // Handle buffer mapping error
 *
 * @endcode
 *
 * This GStreamer buffer contains a batch of one or more video frames from one
 * or more input sources. The batched buffer is basically an array of File
 * Descriptors for the buffers. Please refer to nvbuf_utils API for more
 * information on buffer FDs.
 */
#ifndef _NVBUFFER_H_
#define _NVBUFFER_H_

#ifdef __cplusplus
extern "C"
{
#endif

/** Defines the maximum number of buffers that the batched buffer can contain. */
#define MAX_NVBUFFERS 128

/** Holds the video frame buffer FDs and related information. */
typedef struct _NvBufSurface {
    /** Maximum number of frames that this batch will contain. This is equal to
     * the batch size of the stream muxer. The actual number of filled buffers
     * can be obtained from GstNvStreamMeta. */
    unsigned int num_batched_buffers;
    /** Array of FDs for the individual buffers in the batched buffer. */
    int buf_fds[MAX_NVBUFFERS];
    /** Reserved for future use. */
    void *reserved[MAX_NVBUFFERS];
} NvBufSurface;

#ifdef __cplusplus
}
#endif

#endif /* _NVBUFFER_H_ */
